Since there is one Andriod application that works with various Microchip USB demos, including this demo, the source code is located in just one of the folders.


Please see the following folder for the source code for the Android application:
   <Microchip Application Libraries install directory>/apps/usb/device/hid_custom/utilities/basic_example/android

